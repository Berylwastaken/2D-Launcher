:nerd:
this client is just renamed resent client but for some reason doesnt lag as much. (im not lying about the frames)
