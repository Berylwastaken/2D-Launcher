# piclient
eaglercraft 1.8 piclient, use with caution.
to download, click on pi client, then view raw
then do ctrl+s and save.
